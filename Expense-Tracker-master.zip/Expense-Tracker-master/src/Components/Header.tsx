import React from 'react'
export const Header = () => {
    return (
        <div>
            <h1 className="header">Expense Tracker</h1>
        </div>
    )
}
